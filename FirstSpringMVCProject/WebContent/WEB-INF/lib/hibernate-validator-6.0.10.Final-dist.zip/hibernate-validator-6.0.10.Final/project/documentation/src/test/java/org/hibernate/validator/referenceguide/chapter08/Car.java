package org.hibernate.validator.referenceguide.chapter08;

public class Car {
}
